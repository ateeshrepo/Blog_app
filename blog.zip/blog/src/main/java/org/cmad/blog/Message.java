package org.cmad.blog;

public class Message {

}
